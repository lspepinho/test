# WiFi Password Viewer for MMRL

An inspired project from [veez21](https://github.com/veez21)'s [wpd gist](https://gist.github.com/veez21/4f2541d271809864411e3ffbbe8e3df9), ported to MMRL.

<a href="https://mmrl.dev/repository/grdoglgmr/mmrl_wpd"><img height="45px" alt="Get it on MMRL" src="https://mmrl.dev/assets/badge.svg"></a>

Using Lua to extract local saved wifi passwords

> [!IMPORTANT]
> This module requires WebUI X above v614!

> This module does not extract passwords from unauthorized wifi's. This module is for education purpose only
